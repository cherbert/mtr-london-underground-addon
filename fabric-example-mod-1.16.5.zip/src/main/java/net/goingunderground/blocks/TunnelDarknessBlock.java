package net.goingunderground.blocks;

import net.fabricmc.fabric.api.block.entity.BlockEntityClientSerializable;
import net.goingunderground.Main;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.BlockView;

public class TunnelDarknessBlock extends Block implements BlockEntityProvider {

    public TunnelDarknessBlock(Settings settings) {
        super(settings);
    }

    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.ENTITYBLOCK_ANIMATED;
    }

    @Override
    public BlockEntity createBlockEntity(BlockView world) {
        return new TileEntityTunnelDarkness();
    }

    public static class TileEntityTunnelDarkness extends BlockEntity {

        public TileEntityTunnelDarkness() {
            super(Main.DARK_TILE);
        }

    }
}
